# Sprint "Backlog"

The list of tasks/bugs for the current sprint is displayed below, in this rudimentary backlog.

Work in progress for a task/bug is denoted by :running_man:

## Front end:
- ...
- [ ] :running_man: task #97 (@developerA)
- [ ] :running_man: bug #98 (@developerB)
- ...

## Back end:
- ...
- [ ] :running_man: task #99 (@developerC)
- ...
